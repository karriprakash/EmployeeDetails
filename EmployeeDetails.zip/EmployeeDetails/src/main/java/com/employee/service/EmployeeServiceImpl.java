package com.employee.service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.employee.exception.EmployeeNotFoundException;
import com.employee.model.Employee;
import com.employee.repo.IEmployeeRepository;

@Service
public class EmployeeServiceImpl implements IEmployeeService {

	@Autowired
	private IEmployeeRepository repo;

	public Employee save(Employee emp) {
		repo.save(emp);
		return emp;
	}

	public Employee update(Employee emp) {
		// if given id is present or not
		if (repo.existsById(emp.getId())) {
			return repo.save(emp);
		}

		else {
			throw new EmployeeNotFoundException("Employee '" + emp.getId() + "' Not Found");
		}

	}

	public void delete(Integer id) {
		// check ID exists or not before deleting
		repo.deleteById(getOne(id).getId());
	}

	public Employee getOne(Integer id) {
		Optional<Employee> ope = repo.findById(id);
		if (ope.isPresent())
			return ope.get();
		else
			throw new EmployeeNotFoundException("Employee '" + id + "' Not Found");
	}

	@Override
	public List<Employee> getAll() {
		List<Employee> list = repo.findAll()
				.stream()
				.sorted((e1, e2) -> 
						e2.getId()
							.compareTo(e1.getId()))
				.collect(Collectors.toList());
		return list;
	}

}
