package com.employee.service;

import java.util.List;

import com.employee.model.Employee;


public interface IEmployeeService {

	
	Employee save(Employee emp); 
	
	void delete(Integer id);
	
	Employee getOne(Integer id);
	
	List<Employee> getAll();
	
	Employee update(Employee employee);
	
}
