package com.employee.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.employee.model.Employee;
import com.employee.service.IEmployeeService;

@Controller
@RequestMapping("/employee")
public class EmployeeController {
	
	@Autowired
	private IEmployeeService service;
	
	@GetMapping("/register")
	public String showReg(Model model) {
		Employee e = new Employee();	
		System.out.println("Coming here");
		model.addAttribute("employee", e);		
		return "EmployeeRegister";
	}

	@PostMapping("save")
	public String saveEmployee(@ModelAttribute("employee") Employee employee, Model model) {		
		service.save(employee);
		model.addAttribute("employee", employee);
		return "redirect:all";
	}
	
	public void commonData(Model model) {
		System.out.println("Comming here");
		List<Employee> list = service.getAll();
		System.out.println(list);
		model.addAttribute("list", list);
	}
	
	// display all rows
	@GetMapping("/all")
	public String getAll(Model model) {				
		commonData(model);
		System.out.println("list->"+model.getAttribute("list"));
		return "EmployeeData";
	}
	
	@GetMapping("/edit")
	public String editEmp(
			@RequestParam Integer id,
			Model model
			) {
		Employee emp = service.getOne(id);
		model.addAttribute("employee", emp);
		return "EditEmployee";
	}
	
	@PostMapping("/update")
	public String updateEmp(
			@ModelAttribute Employee employee,
			Model model
			) {		
		service.update(employee);
		//update the data 
		commonData(model);
		model.addAttribute("message", "Employee '"+ employee.getId()+ "' is Updated!");
		return "EmployeeData";
	}
	
	@GetMapping("/delete")
	public String deleteEmp(
			@RequestParam Integer id,
			Model model
			) {		
		String message = null;
		service.delete(id);
		message = "Employee with id:" +id + " was deleted successfully!!";
		model.addAttribute("deleted", message);
		commonData(model);
		return "EmployeeData";
	}
}
